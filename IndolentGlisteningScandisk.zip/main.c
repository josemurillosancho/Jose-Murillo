#include <stdio.h>

int main() {
  int numero1, numero2, resultado;
    printf("\nIngrese un numero: ");
    scanf("%d", &numero1);
    printf("\nIngrese un segundo numero: ");
    scanf("%d", &numero2);
    resultado = numero1 + numero2;
    printf("\nEl resultado es = %d ", resultado );
    return 0;
  }